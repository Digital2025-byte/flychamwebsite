import React from 'react'
import TravelUpdateClient from './TravelUpdateClient'
const page = () => {

    return (
        <TravelUpdateClient />

    )
}

export default page