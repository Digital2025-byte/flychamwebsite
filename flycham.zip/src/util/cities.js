const cities = [
    { name: "Dubai", value: "DXB", label: "Dubai International Airport" },
    { name: "Kuwait", value: "KWI", label: "Kuwait International Airport" },
    { name: "Damascus", value: "DAM", label: "Damascus International Airport" },
    { name: "Aleppo", value: "ALP", label: "Aleppo International Airport" },
    { name: "Muscat", value: "MCT", label: "Muscat International Airport" },
    { name: "Abu Dhabi", value: "AUH", label: "Abu Dhabi International Airport" },
    { name: "Sharjah", value: "SHJ", label: "Sharjah International Airport" },
    { name: "Erbil", value: "EBL", label: "Erbil International Airport" },
    { name: "Baghdad", value: "BGW", label: "Baghdad International Airport" },
];

export default cities